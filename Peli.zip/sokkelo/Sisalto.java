package sokkelo;
import muut.*;

/**
  * Abstrakti yliluokka käytävillä olevalle sisällölle.
  * <p>
  * Harjoitustyö, Olio-ohjelmoinnin perusteet, kevät 2016.
  * <p>
  * @author Noora Toimela (Toimela.Noora.E@studnet.uta.fi),
  * Informaatiotieteiden yksikkö, Tampereen yliopisto.
  */

public abstract class Sisalto extends Sokkelo implements Comparable<Sisalto> {
    /**Sokkelon sisältöjen energia*/
    protected int energia;   
    /**Lista sokkelossa oleville roboteille*/
    private static OmaLista robotit = new OmaLista();
    /**Lista sokkelossa oleville esineille*/
    private static OmaLista esineet = new OmaLista();
   
    public int energia() {
        return energia;
    }
    
    public void energia(int en) {
        energia = en;
    }
    
    public static OmaLista robotit() {
        return robotit;
    }
    
    public static OmaLista esineet() {
        return esineet;
    }

    @Override
    public int compareTo(Sisalto vertailtava) {
        //Vertaile energioita
        if(energia < vertailtava.energia)
            return -1;
        else if(energia == vertailtava.energia)
            return 0;
        else
            return 1;
    }
            
    @Override
    public String toString() {
        return super.toString();
    } 
}