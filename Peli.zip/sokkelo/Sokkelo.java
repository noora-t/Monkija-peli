package sokkelo;
import apulaiset.*;

/**
  * Sokkelon osien abstrakti yläluokka.
  * <p>
  * Harjoitustyö, Olio-ohjelmoinnin perusteet, kevät 2016.
  * <p>
  * @author Noora Toimela (Toimela.Noora.E@studnet.uta.fi),
  * Informaatiotieteiden yksikkö, Tampereen yliopisto.
  */

public abstract class Sokkelo implements Paikallinen {
    /**Sokkelon osien rivi-indeksi*/
    protected int rivi;
    /**Sokkelon osien sarake-indeksi*/
    protected int sarake;
       
    @Override
    public int rivi() {
        return rivi;
    }

    @Override
    public void rivi(int ind) {
        rivi = ind;
    }

    @Override
    public int sarake() {
        return sarake;
    }

    @Override
    public void sarake(int ind) {
        sarake = ind;
    } 
   
    //Kertoo onko paikkaan sallittua asettaa sisältöä (mönkijä, robotti tai esine).
    //Paikka on käytettävissä, jos siinä on käytävää.
    @Override
    public boolean sallittu() {       
        return false;     
    }
    
    @Override
    public String toString() {
        return getClass().getName();
    }     
}
