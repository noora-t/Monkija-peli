package sokkelo;
import apulaiset.*;
import muut.*;

/**
  * Mönkijää mallintava luokka.
  * <p>
  * Harjoitustyö, Olio-ohjelmoinnin perusteet, kevät 2016.
  * <p>
  * @author Noora Toimela (Toimela.Noora.E@studnet.uta.fi),
  * Informaatiotieteiden yksikkö, Tampereen yliopisto.
  */

public class Monkija extends Sisalto implements Suunnallinen {        
    /**Mönkijän lista*/
    private OmaLista mLista = new OmaLista();
    /**Mönkijän suunta*/
    private char suunta;

    public Monkija() {
    }
    
    public Monkija(int r, int s, int e, char su) {
        rivi = r;
        sarake = s;
        energia = e;
        suunta = su;
    }
    
    public OmaLista mLista() {
        return mLista;
    }
    
    public void mLista(OmaLista ml) {
        mLista = ml;
    }
    
    /** Mönkijä ottaa yhden askeleen sokkelossa.
     *
     * @param taulukko
     * @param uusiSuunta
     * @return true, jos robotti voitettiin ja false, jos hävittiin.
     */
    public boolean otaAskel(char uusiSuunta, Object[][] taulukko) {
        int entRivi = rivi;
        int entSarake = sarake;
        //Tosi, jos suunnassa oli käytävää
        boolean liikuttiin = false;
        boolean jatkuu = true;
        
        //Testataan voiko suuntaan mennä.
        //Päivitetään paikka- ja suuntatiedot.
        if(uusiSuunta == POHJOINEN) {
            if(taulukko[rivi - 1][sarake] instanceof Seina)
                System.out.println("Kops!");
            else {
                rivi = rivi - 1; 
                suunta = POHJOINEN;
                liikuttiin = true;
            }
        }
        else if(uusiSuunta == ETELA) {
            if(taulukko[rivi + 1][sarake] instanceof Seina) 
                System.out.println("Kops!");           
            else {
                rivi = rivi + 1; 
                suunta = ETELA;
                liikuttiin = true;
            }
        }
        else if(uusiSuunta == ITA) {
            if(taulukko[rivi][sarake + 1] instanceof Seina) {
                System.out.println("Kops!");
            }
            else {
                sarake = sarake + 1;
                suunta = ITA;
                liikuttiin = true;
            }
        }
        else if(uusiSuunta == LANSI){
            if(taulukko[rivi][sarake - 1] instanceof Seina)
                System.out.println("Kops!");
            else {
                sarake = sarake - 1;
                suunta = LANSI;
                liikuttiin = true;
            }
        }
        
        //Jos liikuttiin sokkelossa
        if(liikuttiin) {
            Logiikka log = new Logiikka();
            Object monkija = log.haeMonkija(taulukko);
            //Paikassa oleva käytävä
            Kaytava paikka = (Kaytava)taulukko[rivi][sarake];                     
            
            Object paikassa;
            boolean loytyi = false;
            //Jos käytävällä on esineitä tai robotteja
            if(paikka.kLista().koko() > 0) {  
                int koko = paikka.kLista().koko();
                for(int ind = 0; ind < koko; ind++) {
                    if(loytyi)
                        paikassa = paikka.kLista().alkio(0);
                    else
                        paikassa = paikka.kLista().alkio(ind);

                    //Poistetaan käytäväpaikalta ja lisätään mönkijän listalle
                    if(paikassa instanceof Esine) {
                        paikka.kLista().poista(paikassa);     
                        ((Monkija)monkija).mLista.lisaa(paikassa);   
                        if(Sisalto.esineet().koko() > 0) {
                            Sisalto.esineet().poista(paikassa);                           
                        }
                        loytyi = true;
                    }
                    //Taistellaan
                    else if(paikassa instanceof Robotti) {
                        jatkuu = taistele((Sisalto)paikassa, (Sisalto)monkija);
                        if(jatkuu) {
                            Sisalto.robotit().poista(paikassa);
                            paikka.kLista().poista(paikassa);         
                        }
                        else
                            paikka.kLista().poista(monkija);
                    }
                }              
            }
            
            //Jos ei hävitty tai taisteltu
            if(jatkuu) {            
                //Lisää mönkijän uuteen paikkaan           
                paikka.kLista().lisaa(monkija);           
                
                //Päivittää esineiden paikat
                paivitaEsineet((Monkija)monkija);
            }
            //Poistaa mönkijän entiseltä paikalta
            Kaytava entPaikka = (Kaytava)taulukko[entRivi][entSarake];          
            entPaikka.kLista().poista(monkija);
        }      
        return jatkuu;
    }
    
    /** Päivittää mönkijän listalla olevien esineiden paikat.
     * 
     * @param m 
     */
    private void paivitaEsineet(Monkija m) {
        for(int d = 0; d < m.mLista.koko(); d++) {
            Esine e = (Esine)m.mLista.alkio(d);
            e.rivi = m.rivi;
            e.sarake = m.sarake;
        }
    }
    
    /** Muunnetaan mönkijän listalla olevia esineitä energiaksi
     *
     * @param kpl
     * @return energia
     */
    public int muunna(int kpl) {
        for(int i = 0; i < kpl; i++) {
            Esine esine = (Esine)mLista.alkio(0);
            int esineenEnergia = esine.energia;
            energia = energia + esineenEnergia;  
            mLista.poista(0);
        }
        return energia;
    }

    /** Taistellaan robotin kanssa
     * Voitto päätellään vertailemalla energioita.
     *
     * @param robotti
     * @param monkija
     * @return voitto
     */
    public boolean taistele(Sisalto robotti, Sisalto monkija) {
        boolean voitto = true;
        if(monkija.compareTo(robotti) == 1 || monkija.compareTo(robotti) == 0) {
            System.out.println("Voitto!");
            voitto = true;
            monkija.energia -= robotti.energia;
        }
        else if(monkija.compareTo(robotti) == -1) {
                System.out.println("Tappio!");
            voitto = false;
        }
        return voitto;
    }
    
    @Override
    public char suunta() {
       return suunta;
    }

    @Override
    public void suunta(char ilmansuunta) {
        suunta = ilmansuunta;
    }
    
    @Override
    public String toString() {
        return super.toString();
    } 
}