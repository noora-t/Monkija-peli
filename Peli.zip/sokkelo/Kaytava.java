package sokkelo;
import muut.*;
/**
  * Sokkelon käytäväpaikkoja mallintava luokka.
  * <p>
  * Harjoitustyö, Olio-ohjelmoinnin perusteet, kevät 2016.
  * <p>
  * @author Noora Toimela (Toimela.Noora.E@studnet.uta.fi),
  * Informaatiotieteiden yksikkö, Tampereen yliopisto.
  */

public class Kaytava extends Sokkelo {
    /**Käytäväpaikan lista*/
    private OmaLista kLista = new OmaLista();
    
    public Kaytava() {      
    }
    
    public Kaytava(int r, int s) {
        rivi = r;
        sarake = s;
    }
    
    public OmaLista kLista() {
        return kLista;
    }
    
    public void kLista(OmaLista k) {
        kLista = k;
    }
    
    @Override
    public String toString() {
        return super.toString();       
    } 
    
    //Kertoo onko paikkaan sallittua asettaa sisältöä (mönkijä, robotti tai esine).
    //Paikka on käytettävissä, jos siinä on käytävää.
    @Override
    public boolean sallittu() {       
        return true;    
    }
}