package sokkelo;
import apulaiset.*;

/**
  * Robottia mallintava luokka.
  * <p>
  * Harjoitustyö, Olio-ohjelmoinnin perusteet, kevät 2016.
  * <p>
  * @author Noora Toimela (Toimela.Noora.E@studnet.uta.fi),
  * Informaatiotieteiden yksikkö, Tampereen yliopisto.
  */

public class Robotti extends Sisalto implements Suunnallinen {
    /**Robotin suunta*/
    private char suunta;
    
    public Robotti() {     
    }
    
    public Robotti(int r, int s, int e, char su) {
        rivi= r;
        sarake = s;
        energia = e;
        suunta = su;
    }
    
    @Override
    public char suunta() {
       return suunta;
    }

    @Override
    public void suunta(char ilmansuunta) {
        suunta = ilmansuunta;
    }
    
    @Override
    public String toString() {
        return super.toString();
    }            
}