package sokkelo;

/**
  * Sokkelon seiniä mallintava luokka.
  * <p>
  * Harjoitustyö, Olio-ohjelmoinnin perusteet, kevät 2016.
  * <p>
  * @author Noora Toimela (Toimela.Noora.E@studnet.uta.fi),
  * Informaatiotieteiden yksikkö, Tampereen yliopisto.
  */

public class Seina extends Sokkelo {
    public Seina() {       
    } 
    
    public Seina(int r, int s) {
        rivi = r;
        sarake = s;
    }
    
    @Override
    public String toString() {
        return super.toString();
    } 
}