import muut.*;
import apulaiset.*;

/**
  * Ajoluokka
  * <p>
  * Harjoitustyö, Olio-ohjelmoinnin perusteet, kevät 2016.
  * <p>
  * @author Noora Toimela (Toimela.Noora.E@studnet.uta.fi),
  * Informaatiotieteiden yksikkö, Tampereen yliopisto.
  */

public class Oope2016HT {
    public static void main(String[] args) {
        //Tulostaa otsikon
        System.out.println("***********");
        System.out.println("* SOKKELO *");
        System.out.println("***********");
      
        //Pelin lataus
        Logiikka log = new Logiikka();
        int siemen = log.alustaTaulukko();
        Automaatti.alusta(siemen);
        Object[][] taulukko = log.teeTaulukko();               
        
        //Pääsilmukan kutsu
        Kayttoliittyma ui = new Kayttoliittyma();
        ui.kysyKomento(log, taulukko);
    }  
}