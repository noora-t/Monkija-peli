package muut;

/**
  * Abstrakti yliluokka käytävillä olevalle sisällölle.
  * <p>
  * Harjoitustyö, Olio-ohjelmoinnin perusteet, kevät 2016.
  * <p>
  * @author Noora Toimela (Toimela.Noora.E@studnet.uta.fi),
  * Informaatiotieteiden yksikkö, Tampereen yliopisto.
  */

public abstract class Sisalto extends Sokkelo implements Comparable<Sisalto> {
    /**Sokkelon sisältöjen energia*/
    protected int energia;
    
    protected OmaLista robotit;
    
    public int energia() {
        return energia;
    }
    public void energia(int e) {
        energia = e;
    }
   

   /* Toteuta Comparable-rajapinnan compareTo-metodi. Käytä metodia mönkijän
ja robotin vertailuun kamppailussa sekä lisäyspaikan hakemiseen OmaListaluokan
operaatiossa (luku 4.3). 
*/
    //Object-luokan compareTo-metodin toteutus
    @Override
    public int compareTo(Sisalto vertailtava) {
        //Vertaile energioita
        if(energia < vertailtava.energia())
            return -1;
        else if(energia == vertailtava.energia())
            return 0;
        else
            return 1;
    }
            
    //Object-luokan toString-metodin korvaus
    @Override
    public String toString() {
        return super.toString();
    } 
}