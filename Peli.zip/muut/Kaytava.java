package muut;
/**
  * Sokkelon käytäväpaikkoja mallintava luokka.
  * <p>
  * Harjoitustyö, Olio-ohjelmoinnin perusteet, kevät 2016.
  * <p>
  * @author Noora Toimela (Toimela.Noora.E@studnet.uta.fi),
  * Informaatiotieteiden yksikkö, Tampereen yliopisto.
  */

public class Kaytava extends Sokkelo {
    /**Käytäväpaikan lista*/
    public static OmaLista kLista;
    
    public Kaytava() {
        //alusta klista
        kLista = new OmaLista();
    }
    public Kaytava(int r, int s, OmaLista kLista) {
        rivind = r;
        sarind = s;
        kLista = new OmaLista();
    }
    
    public OmaLista kLista() {
        return kLista;
    }
    
    public void kLista(OmaLista k) {
        kLista = k;
    }
    
    //toString-metodin korvaus
    @Override
    public String toString() {
        return super.toString();
    } 
}
