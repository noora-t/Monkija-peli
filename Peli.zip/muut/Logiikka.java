package muut;
import apulaiset.*;
import sokkelo.*;

/**
  * Logiikan sisältävä luokka.
  * <p>
  * Harjoitustyö, Olio-ohjelmoinnin perusteet, kevät 2016.
  * <p>
  * @author Noora Toimela (Toimela.Noora.E@studnet.uta.fi),
  * Informaatiotieteiden yksikkö, Tampereen yliopisto.
  */

public class Logiikka {   
    /**Sokkelon rivilukumäärä*/
    private int rivilkm;
    /**Sokkelom sarakelukumäärä*/
    private int sarakelkm;
    /**Olioviitteen rivi-indeksi*/
    private int rivind;
    /**Olioviitteen sarake-indeksi*/
    private int sarind;
    /**Sokkelo*/
    public Object[][] taulukko;
    
    /** Alustetaan sokkelona toimiva taulukko.
     * Luetaan sokkelo.txt tiedoston ensimmäiseltä
     * riviltä siemenluku ja rivien ja sarakkeiden
     * lukumäärä.
     * 
     * @return siemen 
     */
    public int alustaTaulukko() {
        int r = -1;
        Tiedosto td = new Tiedosto();
        String riviapu = td.lueTiedosto(r);
        String[] osat = riviapu.split("[|]");
        
        for (int t = 0; t < osat.length; t++) 
            osat[t] = osat[t].trim();
        int siemen = Integer.parseInt(osat[0]);
        rivilkm = Integer.parseInt(osat[1]);
        sarakelkm = Integer.parseInt(osat[2]);        
        return siemen;
    }
    
    /** Tehdään sokkelona toimiva taulukko.
     * Tiedostoa sokkelo.txt luetaan rivi kerrallaan,
     * luodaan oliot, ja lisätään niiden viitteet taulukkoon
     * ja listoille.
     * @return taulukko
     */
    public Object[][] teeTaulukko() {
        //Tyhjentää listat lataus-komennolle
        for(int i = 0; i < Sisalto.robotit().koko(); i++)
            Sisalto.robotit().poistaAlusta();
        for(int i = 0; i < Sisalto.esineet().koko(); i++)
            Sisalto.esineet().poistaAlusta();
       
        taulukko = new Object[rivilkm][sarakelkm];
        Tiedosto td = new Tiedosto();
        int luettavaRiviNro = 0;
        
        //Apuviite edellisen kierroksen olioon
        Object edellinen = new Object();
        
        //Silmukoidaan tiedoston kaikki rivit läpi
        while(luettavaRiviNro < td.laskeRivit() - 1) { 
            td = new Tiedosto();
            String line = td.lueTiedosto(luettavaRiviNro);
            String[] osat = line.split("[|]");
            Object obj = teeOliot(osat);           
       
            /* Apuviitteen avulla tehdään viitteet olioista
            *  sokkelon osiin. Lisätään Kaytavan ja 
            *  Monkijan listoille viitteet olioihin.
            */
            if(obj instanceof Seina) {
                taulukko[rivind][sarind] = obj;
                edellinen = obj;
            }
            else if(obj instanceof Kaytava) {
                taulukko[rivind][sarind] = obj;
                edellinen = obj;
            }
            else if(obj instanceof Esine && edellinen instanceof Monkija) {
                OmaLista mLista = ((Monkija)edellinen).mLista();
                mLista.lisaa(obj);
            }           
            else if(obj instanceof Esine && edellinen instanceof Kaytava) {
                OmaLista kLista = ((Kaytava)edellinen).kLista();
                kLista.lisaa(obj);
                Sisalto.esineet().lisaa(obj);
            }
            else if(obj instanceof Robotti && edellinen instanceof Kaytava) {
                OmaLista kLista = ((Kaytava)edellinen).kLista(); 
                kLista.lisaa(obj);
                Sisalto.robotit().lisaaLoppuun(obj);
            }
            else if(obj instanceof Monkija && edellinen instanceof Kaytava) {
                OmaLista kLista = ((Kaytava)edellinen).kLista();
                kLista.lisaa(obj); 
                edellinen = obj;
            }
            luettavaRiviNro++;
        }
        return taulukko;
    }   
    
    /** Luetaan tiedostoa ja tehdään olioita
     * Sokkelo.txt riveistä. Pilkotaan luokka ja tiedot ja
     * tehdään oliot niiden perusteella. Palautetaan viite 
     * luotuun olioon.
     * 
     * @param osat
     * @return olio
     */
    private Object teeOliot(String[] osat) {
        String luokka;
        int energia = 0;
        char suunta = ' ';
        //Palautettava olio-viite
        Object olio = new Object();
        
        for (int t = 0; t < osat.length; t++)
            osat[t] = osat[t].trim();
        luokka = osat[0];
        rivind = Integer.parseInt(osat[1]);
        sarind = Integer.parseInt(osat[2]);
        if(osat.length >= 4)
            energia = Integer.parseInt(osat[3]);
        if(osat.length == 5)
            suunta = osat[4].charAt(0);

        if(luokka.equals("Esine")) 
            olio = new Esine(rivind, sarind, energia);
        else if(luokka.equals("Monkija"))
            olio = new Monkija(rivind, sarind, energia, suunta);
        else if(luokka.equals("Robotti"))
            olio = new Robotti(rivind, sarind, energia, suunta);
        else if(luokka.equals("Kaytava"))
            olio = new Kaytava(rivind, sarind);
        else if(luokka.equals("Seina"))
            olio = new Seina(rivind, sarind);
       
        return olio;
    }  
    
    /** Tulostetaan sokkelon kartta.
     * Haetaan taulukosta luokat ja niiden perusteella
     * tulostetaan luokkia kuvaavat merkit.
     * @param taulu
     */
    public void tulostaKartta(Object[][] taulu) {
        //Apumuttuja edellisen kierroksen merkkiin
        String edel = "";
        //Tulostettava merkki
        String merkki = "f";
        
        //Käydään sokkeloa läpi ja tulostetaan olioiden 
        //luokkia kuvaavat merkit
        for(int a = 0; a < taulu.length; a++) {
            for(int b = 0; b < taulu[0].length; b++) {
                if(taulu[a][b] instanceof Seina)
                    System.out.print(".");
                else if(taulu[a][b] instanceof Kaytava) { 
                    Kaytava kaytava = (Kaytava)taulu[a][b];
                    
                    //Jos käytävän listalla on sisältöä
                    //tulostetaan luokkia kuvaavat merkit
                    if(kaytava.kLista().koko() > 0) {
                        for(int ind = 0; ind < kaytava.kLista().koko(); ind++) {
                            String luokanNimi = haeListalta(ind, kaytava);
                            if(luokanNimi.equals("E") && !edel.equals("R") && !edel.equals("M"))
                                merkki = "E";
                            else if((edel.equals("") || edel.equals("E")) &&
                            luokanNimi.equals("R"))
                                merkki = "R";
                            else if((edel.equals("") || edel.equals("E") ||
                            edel.equals("R")) && luokanNimi.equals("M"))        
                                merkki = "M";
                            else
                                merkki = edel;
                 
                            edel = luokanNimi;                               
                        }
                        
                        System.out.print(merkki);
                        edel = "";
                    }
                    //Jos käytävän listalla ei ole sisältöä
                    else 
                        System.out.print(" ");
                }
            }
            System.out.println();
        }
   } 

    /** Hakee käytävän listalta olioviitteiden luokat
     *
     * @param paikka
     * @param kaytava
     * @return nimi
     */    
    private String haeListalta(int paikka, Kaytava kaytava) {
        //Palautettava luokan nimi
        String nimi = "";
        
        // Selvitetään metaolion avulla tietoalkion luokan nimi
        String alkionLuokanNimi = kaytava.kLista().alkio(paikka).getClass().getSimpleName();
        if (alkionLuokanNimi.equals("Esine"))
            nimi = "E";
        else if(alkionLuokanNimi.equals("Robotti"))
            nimi = "R";  
        else if(alkionLuokanNimi.equals("Monkija"))
            nimi = "M";

        return nimi;
    }    
    
    /** Hakee mönkijän sokkelosta.
     * 
     * @param taulukko
     * @return monkija
     */
    public Monkija haeMonkija(Object[][] taulukko) {
        //Palautettava Monkija-olio
        Monkija monkija = new Monkija();
        boolean loytyi = false;
        //Käydään sokkeloa läpi ja etsitään mönkijää 
        //käytäväpaikkojen listoilta
        for (int a = 0; a < taulukko.length; a++) {
            for(int b = 0; b < taulukko[0].length && !loytyi; b++) {
                Object olio = taulukko[a][b];
                if(olio.getClass().getSimpleName().equals("Kaytava")) {
                    Kaytava kaytava = (Kaytava)olio;
                    for(int ind = 0; ind < kaytava.kLista().koko(); ind++) {
                        String nimi = haeListalta(ind, kaytava);
                        if(nimi.equals("M")) {
                            monkija = (Monkija)kaytava.kLista().alkio(ind); 
                            loytyi = true;
                        }
                    }
                }
            }
        } 
        return monkija;
    }
    
    /** Liikuttaa robotteja sokkelossa ja päivittää niiden paikan ja suunnan.
     * 
     * @param taulu
     * @return voitto
     */
    public boolean liikutaRobotteja(Object[][] taulu) {
        //Voitettiinko mönkijä, jos sellainen kohdattiin
        boolean jatkuu = true;
        
        //Poistaa robotit entisiltä paikoiltaan sokkelosta
        for(int ind = 0; ind < Sisalto.robotit().koko(); ind++) {
            Robotti poistettava = (Robotti)Sisalto.robotit().alkio(ind);
            int entRivi = poistettava.rivi();
            int entSarake = poistettava.sarake();
            Kaytava kaytava = (Kaytava)taulu[entRivi][entSarake];
            kaytava.kLista().poista(poistettava);
        }
        
        //Päivittää robottien tiedot
        Automaatti.paivitaPaikat(Sisalto.robotit(), taulu);

        Robotti lisattava;
        //Lippumuuttuja, edellisen robotin tapahtumille
        boolean taisteltiin = false;
                
        int pituus = Sisalto.robotit().koko();
        //Lisää robotit uuteen paikkaansa sokkelossa
        for(int ind = 0; ind < pituus && jatkuu; ind++) {
            if(taisteltiin)
                lisattava = (Robotti)Sisalto.robotit().alkio(ind - 1);
            else
                lisattava = (Robotti)Sisalto.robotit().alkio(ind);
            
            int rivInd = lisattava.rivi();
            int sarInd = lisattava.sarake();
            Kaytava kaytava = (Kaytava)taulu[rivInd][sarInd];
            kaytava.kLista().lisaa(lisattava);
            
            //Jos uudella paikalla on mönkijä, taistellaan
            int koko = kaytava.kLista().koko();
            for(int i = 0; i < koko; i++) {
                Object paikassa = kaytava.kLista().alkio(i);
                if(paikassa instanceof Monkija) {
                    jatkuu = ((Monkija)paikassa).taistele(lisattava, (Monkija)paikassa);
                    if(jatkuu) {
                        Sisalto.robotit().poista(lisattava);
                        kaytava.kLista().poista(lisattava);         
                    }
                    else
                        kaytava.kLista().poista(paikassa);
                    taisteltiin = true;                                     
                }
            }
        } 
        return jatkuu;
    }
}