package muut;
/**
 * Oope harjoitustyö kevät 2016
 * Noora Toimela
 * Toimela.Noora.E@student.uta.fi
 */

public class Plantti extends Sisalto {
    //Rakentajat
    
    public Plantti() {
        
    }
    
    public Plantti(int r, int s) {
        rivind = r;
        sarind = s;
    } 
    
    //toString-metodin korvaus
    @Override
    public String toString() {
        return super.toString();
    } 
    
}
