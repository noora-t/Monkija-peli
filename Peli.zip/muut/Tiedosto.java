package muut;
import sokkelo.*;
import java.io.*;

/**
  * Tiedoston lukeminen ja tiedostoon kirjoittaminen.
  * <p>
  * Harjoitustyö, Olio-ohjelmoinnin perusteet, kevät 2016.
  * <p>
  * @author Noora Toimela (Toimela.Noora.E@studnet.uta.fi),
  * Informaatiotieteiden yksikkö, Tampereen yliopisto.
  */

public class Tiedosto {
    /**Luettava tiedosto*/
    final String TIEDNIMI = "sokkelo.txt";
    /**Luettava rivi*/
    String rivi;
    
    /** Laskee tiedoston rivien lukumäärän.
     * 
     * @return riviLkm
     */
    public int laskeRivit() {
        int riviLkm = 0;
        
        try {
            //Avataan syötevirta ja tehdään lukija
            FileInputStream syotevirta = new FileInputStream(TIEDNIMI);
            InputStreamReader lukija = new InputStreamReader(syotevirta);
            BufferedReader puskuroituLukija = new BufferedReader(lukija); 
         
            //Jaetaan rivit osiin ja luetaan rivejä
            while (puskuroituLukija.ready()) {
                rivi = puskuroituLukija.readLine();
                riviLkm++;
            }
            
            //Suljetaan syötevirta
             puskuroituLukija.close();
        }
        catch (FileNotFoundException e) {
             System.out.print("Tiedosto hukassa!");
        }
        catch (IOException e) {
            System.out.print("Lukuvirhe!");
        }

        return riviLkm;
    }
    
    /** Lukee tiedoston rivejä.
     * 
     * @param luku
     * @return rivi
     */
    public String lueTiedosto(int luku) {
        int kierros = -2;
        
        try {
            //Avataan syötevirta ja tehdään lukija
            FileInputStream syotevirta = new FileInputStream(TIEDNIMI);
            InputStreamReader lukija = new InputStreamReader(syotevirta);
            BufferedReader puskuroituLukija = new BufferedReader(lukija); 
         
            //Jaetaan rivit osiin ja luetaan rivejä
            while (puskuroituLukija.ready() && kierros < luku) {
                rivi = puskuroituLukija.readLine();
                kierros++;
            }
            
            //Suljetaan syötevirta
             puskuroituLukija.close();
        }
        catch (FileNotFoundException e) {
             System.out.print("Tiedosto hukassa!");
        }
        catch (IOException e) {
            System.out.print("Lukuvirhe!");
        }
        
        kierros = 0;
        return rivi;      
    }
   
    /** Kirjoittaa taulukon tiedot tiedostoon.
     * 
     * @param taulu 
     */
    public void kirjoitaTiedostoon(Object[][] taulu) {
        int r = -1;
        String rivi = lueTiedosto(r);
        String[] osat = rivi.split("[|]");
        
        for (int t = 0; t < osat.length; t++) 
            osat[t] = osat[t].trim();
        int siemen = Integer.parseInt(osat[0]);
            
        try {
            // Luodaan tiedosto-olio
            File tiedosto = new File(TIEDNIMI);

            // Luodaan tulostusvirta ja
            // liitetään se tiedostoon
            FileOutputStream tulostusvirta = new FileOutputStream(tiedosto);
         
            // Luodaan virtaan kirjoittaja
            PrintWriter kirjoittaja = new PrintWriter(tulostusvirta, true);           
        
            // Kirjoitetaan siemenluku ja rivi- ja sarakeindeksit tiedostoon
            kirjoittaja.print(Muotoilu.kentita(Integer.toString(siemen),
            4 - Integer.toString(siemen).length()));
            kirjoittaja.print(Muotoilu.kentita(Integer.toString(taulu.length),
            4 - Integer.toString(taulu.length).length()));
            kirjoittaja.print(Muotoilu.kentita(Integer.toString(taulu[0].length),
            4 - Integer.toString(taulu[0].length).length()));
            kirjoittaja.println();
            
            //Käydään taulukkoa läpi
            for(int a = 0; a < taulu.length; a++) {
                for(int b = 0; b < taulu[0].length; b++) {
                    //Kentitetään seinät ja käytävät
                    kirjoittaja.print(Muotoilu.kentitaOliot(taulu[a][b]));
                    kirjoittaja.println();

                    //Kentitetään mahdolliset käytävän sisällöt
                    if(taulu[a][b] instanceof Kaytava) {                   
                        Kaytava kaytava = (Kaytava)taulu[a][b];
                        if(kaytava.kLista().koko() > 0) {
                            for(int i = 0; i < kaytava.kLista().koko(); i++) {
                                Object listalla = kaytava.kLista().alkio(i);
                                if(listalla instanceof Monkija) {
                                    //Kentitetään mönkijän tiedot
                                    kirjoittaja.print(Muotoilu.kentitaOliot(listalla));
                                    kirjoittaja.println();

                                    //Kentitetään mahdolliset mönkijän esineet
                                    if(((Monkija)listalla).mLista().koko() > 0) {
                                        for(int j = 0; j < ((Monkija)listalla).mLista().koko(); j++) {
                                            Object mListalla = ((Monkija)listalla).mLista().alkio(j);

                                            kirjoittaja.print(Muotoilu.kentitaOliot(mListalla));
                                            kirjoittaja.println();
                                        }
                                    }
                                }
                                else if(listalla instanceof Robotti) {
                                    //Kentitetään robotin tiedot
                                    kirjoittaja.print(Muotoilu.kentitaOliot(listalla));
                                    kirjoittaja.println();
                                }
                                else if(listalla instanceof Esine) {
                                    //Kentitetään esineen tiedot
                                    kirjoittaja.print(Muotoilu.kentitaOliot(listalla));
                                    kirjoittaja.println();
                                }
                            }
                        }
                    }
                }
            }  
            // Suljetaan tiedosto
            kirjoittaja.close();
        }
        catch (IOException e) {
            System.out.println(e);
        }
    }
}