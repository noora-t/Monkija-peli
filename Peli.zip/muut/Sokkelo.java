package muut;
import apulaiset.*;

/**
 * Oope harjoitustyö kevät 2016
 * Noora Toimela
 * Toimela.Noora.E@student.uta.fi
 */

public abstract class Sokkelo implements Paikallinen {
    //Attribuutit
    protected int rivind;
    protected int sarind;
    private String merkki;
    
    public String merkki() {
        return merkki;
    }
    
    //Paikan rivi-indeksin palauttava metodi.
    @Override
    public int rivi() {
        return 0;
    }

    //Paikan rivi-indeksin asettava metodi.
    @Override
    public void rivi(int ind) {
        
    }

    //Paikan sarakeindeksin palauttava metodi.
    @Override
    public int sarake() {
        return 0;
    }

    //Paikan sarakeindeksin asettava metodi.
    @Override
    public void sarake(int ind) {
        
    } 
   
    //Kertoo onko paikkaan sallittua asettaa sisältöä (mönkijä, robotti tai esine).
    //Paikka on käytettävissä, jos siinä on käytävää.
    @Override
    public boolean sallittu() {
        return true;
    }
    
    //toString-metodin kutsu
    @Override
    public String toString() {
        return getClass().getName();
    } 
}
