package muut;

/**
  * Esinettä mallintava luokka.
  * <p>
  * Harjoitustyö, Olio-ohjelmoinnin perusteet, kevät 2016.
  * <p>
  * @author Noora Toimela (Toimela.Noora.E@studnet.uta.fi),
  * Informaatiotieteiden yksikkö, Tampereen yliopisto.
  */

public class Esine extends Sisalto {
    public Esine() {
        
    }
    public Esine(int r, int s, int e) {
        rivind = r;
        sarind = s;
        energia = e;
    }
    
    //toString-metodin korvaus
    @Override
    public String toString() {
        return super.toString();
    } 
            
}
