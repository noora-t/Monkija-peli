package muut;
import sokkelo.*;

/**
  * Tulosteiden muotoiluun keskittyvä luokka.
  * <p>
  * Harjoitustyö, Olio-ohjelmoinnin perusteet, kevät 2016.
  * <p>
  * @author Noora Toimela (Toimela.Noora.E@studnet.uta.fi),
  * Informaatiotieteiden yksikkö, Tampereen yliopisto.
  */

public class Muotoilu {      
    /** Kentittää annetun olion tiedot
     * 
     * @param olio
     * @return rivi
     */
    public static String kentitaOliot(Object olio) {
        //Palautettava tekstirivi
        String rivi = "";
        //Olion luokan nimi
        String luokanNimi = olio.getClass().getSimpleName();

        Monkija mon;
        Robotti rob;
        Esine esi;
        Kaytava kay;
        Seina sei;
        
        //Lisätään kentitetyt tiedot palautettavaan tekstiriviin
        if(olio instanceof Monkija) {
            mon = (Monkija)olio;
            rivi += kentita(luokanNimi, 9 - luokanNimi.length());
            rivi += kentita(Integer.toString(mon.rivi()), 4 - Integer.toString(mon.rivi()).length());
            rivi += kentita(Integer.toString(mon.sarake()), 4 - Integer.toString(mon.sarake()).length());
            rivi += kentita(Integer.toString(mon.energia()), 4 - Integer.toString(mon.energia()).length()); 
            rivi += kentita(Character.toString(mon.suunta()), 4 - Character.toString(mon.suunta()).length());
        }
        else if(olio instanceof Robotti) {
            rob = (Robotti)olio;
            rivi += kentita(luokanNimi, 9 - luokanNimi.length());
            rivi += kentita(Integer.toString(rob.rivi()), 4 - Integer.toString(rob.rivi()).length());
            rivi += kentita(Integer.toString(rob.sarake()), 4 - Integer.toString(rob.sarake()).length());
            rivi += kentita(Integer.toString(rob.energia()), 4 - Integer.toString(rob.energia()).length()); 
            rivi += kentita(Character.toString(rob.suunta()), 4 - Character.toString(rob.suunta()).length());
        }
        else if(olio instanceof Esine) {
            esi = (Esine)olio;
            rivi += kentita(luokanNimi, 9 - luokanNimi.length());
            rivi += kentita(Integer.toString(esi.rivi()), 4 - Integer.toString(esi.rivi()).length());
            rivi += kentita(Integer.toString(esi.sarake()), 4 - Integer.toString(esi.sarake()).length());
            rivi += kentita(Integer.toString(esi.energia()), 4 - Integer.toString(esi.energia()).length()); 
        }
        else if(olio instanceof Seina) {
            sei = (Seina)olio;
            rivi += kentita(luokanNimi, 9 - luokanNimi.length());
            rivi += kentita(Integer.toString(sei.rivi()), 4 - Integer.toString(sei.rivi()).length());
            rivi += kentita(Integer.toString(sei.sarake()), 4 - Integer.toString(sei.sarake()).length());
        }
        else if(olio instanceof Kaytava) {
            kay = (Kaytava)olio;
            rivi += kentita(luokanNimi, 9 - luokanNimi.length());
            rivi += kentita(Integer.toString(kay.rivi()), 4 - Integer.toString(kay.rivi()).length());
            rivi += kentita(Integer.toString(kay.sarake()), 4 - Integer.toString(kay.sarake()).length());
        }
        
        return rivi;
    }
    
    /** Kentittää annetun tiedon
     * 
     * @param tieto
     * @param vl
     * @return mjono
     */
    public static String kentita(String tieto, int vl) {
        //Palautettava merkkijono
        String mjono = "";
        mjono = mjono + tieto;
        for(int i = 0; i < vl; i++) {
            mjono = mjono + " ";
        }
        mjono = mjono + "|";
        
        return mjono;
    }
    
    /** Palauttaa mönkijän tiedot ja esineet kentitettynä.
     * 
     * @param taulu
     * @return rivit
     */
    public static String inventoi(Object[][] taulu) {
        Logiikka log = new Logiikka();
        Monkija monkija = log.haeMonkija(taulu);
        //Palautettavat tekstirivit
        String rivit = "";
        
        //Kentitetään mönkijän tiedot
        rivit += kentitaOliot(monkija);
        
        Esine esine; 
        //Kentitetään mönkijän esineiden tiedot
        for(int i = 0; i < monkija.mLista().koko(); i++) {            
            rivit += "-";
            esine = (Esine)monkija.mLista().alkio(i);
            rivit += kentitaOliot(esine);   
        }
        
        return rivit;
    }
    
    /** Palauttaa annetussa suunnassa olevien asioiden tiedot.
     * 
     * @param suunta
     * @param taulu
     * @return 
     */
    public static String katsoViereinen(char suunta, Object[][] taulu) {
        Logiikka log = new Logiikka();
        Monkija monkija = log.haeMonkija(taulu);
        
        //Palautettava merkkijono
        String viereinen = "";
        //Mönkijän rivi-indeksi
        int rivi = monkija.rivi();
        //Mönkijän sarake-indeksi
        int sarake = monkija.sarake();
        //Apumuuttuja viereiselle käytäväpaikalle
        Kaytava apu = new Kaytava();
        
        //Päätellään suunnan perusteella käytäväpaikan koordinaatit
        switch (suunta) {
            case 'e':
                apu = (Kaytava)taulu[rivi + 1][sarake];
                break;
            case 'p':
                apu = (Kaytava)taulu[rivi - 1][sarake];
                break;
            case 'i':
                apu = (Kaytava)taulu[rivi][sarake + 1];
                break;
            case 'l':
                apu = (Kaytava)taulu[rivi + 1][sarake - 1];
                break;
            default:
                break;
        }
        
        //Kentitetään käytäpaikan tiedot
        viereinen += kentitaOliot(apu);
       
        //Kentitetään käytävällä mahdollisesti olevat esineet ja robotit
        if(apu.kLista().koko() > 0) {
            for(int i = 0; i < apu.kLista().koko(); i ++) {
                viereinen += "-"; 
                Object paikalla = apu.kLista().alkio(i);
                if(paikalla instanceof Esine) 
                    viereinen += kentitaOliot(paikalla); 
                else if(paikalla instanceof Robotti) 
                    viereinen += kentitaOliot(paikalla);                 
            }   
        } 
        return viereinen;
    }
}