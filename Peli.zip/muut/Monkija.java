package muut;
import apulaiset.*;

/**
  * Mönkijää mallintava luokka.
  * <p>
  * Harjoitustyö, Olio-ohjelmoinnin perusteet, kevät 2016.
  * <p>
  * @author Noora Toimela (Toimela.Noora.E@studnet.uta.fi),
  * Informaatiotieteiden yksikkö, Tampereen yliopisto.
  */

public class Monkija extends Sisalto implements Suunnallinen {   
    /**Mönkijän lista*/
    public static OmaLista mLista;
    /**Mönkijän suunta*/
    public char suunta;

    public Monkija() {
        mLista = new OmaLista();
    }
    public Monkija(int r, int s, int e, char su) {
        rivind = r;
        sarind = s;
        energia = e;
        suunta = su;
        mLista = new OmaLista();
    }
    
    public OmaLista mLista() {
        return mLista;
    }
    
    public void kLista(OmaLista m) {
        mLista = m;
    }
    
    /** Mönkijä ottaa yhden askeleen sokkelossa.
     * Voitto päätellään vertailemalla uusia terveydentiloja.
     *
     * @param t
     * @param uusiSuunta
     * @return true, jos robotti voitettiin ja false, jos hävittiin.
     */
    public boolean otaAskel(int[][] t, char uusiSuunta) {
        if(uusiSuunta == POHJOINEN)
            rivind = rivind - 1;
        else if(uusiSuunta == ETELA)
            rivind = rivind + 1;
        else if(uusiSuunta == ITA)
            sarind = sarind + 1;
        else if(uusiSuunta == LANSI)
            sarind = sarind - 1;
        
//        if(käytävän lista on tyhjä)
//            //Poista mönkijä nykyisen käytäväpaikan listalta
//            //Lisää mönkijä käytäväpaikan listalle
//            //t[rivind][sarind] = Monkija;
//            
//        else if(listalla on esine)
//            lisääListalle();
//        
//        
//        else if(listalla on robotti) {
//            boolean voitto = taistele(energia, Robotti.energia);
//                return voitto;          
//        }
        return true;
    }
     
    /** Muunnetaan mönkijän listalla olevia esineitä energiaksi
     *
     * @param 
     * @param 
     * @param 
     * @return energia
     */
//    public int muunna(int energia, int uusi, int kpl) {
//        for(int i = 0; i < kpl; i++) {
//            valitse listan alusta esine
//            energia = energia + esineen energia;
//            return energia;
//        }
//    }
    
    /** Taistellaan robotin kanssa
     * Voitto päätellään vertailemalla energioita.
     *
     * @param re robotin energia
     * @param me mönkijän energia
     * @return true, jos tuli voitto, ja -false, jos häviö.
     */
//    public boolean taistele(int re, int me) {
//        if(me.compareTo(re) == 1 || me.compareTo(re) == 0) {
//            System.out.println("Voitto!");
//            return true;
//        }
//        else if(me.compareTo(re) == -1) {
//                System.out.println("Tappio");
//            return false;
//        }
//    }
    
    // Olion suunnan palauttava metodi.
    @Override
    public char suunta() {
       return suunta;
    }

    /** Olion suunnan asettava metodi.
      *
      * @param ilmansuunta uusi suunta, joka on jokin neljästä pääilmansuunnasta.
      * @throws IllegalArgumentException jos parametri ei ollut jokin yllä
      * määritellyistä pääilmansuunnan symboleista.
      */
    @Override
    public void suunta(char ilmansuunta) throws IllegalArgumentException {
        suunta = ilmansuunta;
    }
    
    //toString-metodin korvaus
    @Override
    public String toString() {
        return super.toString();
    } 
}
