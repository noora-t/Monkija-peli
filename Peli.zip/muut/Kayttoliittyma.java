package muut;
import apulaiset.*;
import sokkelo.*;

/**
  * Käyttöliittymän sisältävä luokka.
  * <p>
  * Harjoitustyö, Olio-ohjelmoinnin perusteet, kevät 2016.
  * <p>
  * @author Noora Toimela (Toimela.Noora.E@studnet.uta.fi),
  * Informaatiotieteiden yksikkö, Tampereen yliopisto.
  */

public class Kayttoliittyma { 
    /** Kysytään käyttäjältä komentoa silmukassa
     *
     * @param log
     * @param taulukko
     */
    public void kysyKomento(Logiikka log, Object[][] taulukko) {
        //Lippumuuttuja ohjelman jatkumiselle
        boolean jatka = true;
        Object monkija;               

        //Silmukoidaan kunnes jatka on epätosi
        //tai kaikki esineet on kerätty
        do {  
            monkija = log.haeMonkija(taulukko);
            //Lippumuuttuja robottien liikuttamiselle
            boolean liikRob = false;
            //Lippumuuttuja kartan tulostamiselle
            boolean tulosta = false;
            
            //Kysytään komento
            System.out.println("Kirjoita komento:");
            String syote = In.readString();

            //Apumuuttujia muunna-komennolle
            int mKoko = ((Monkija)monkija).mLista().koko();
            String komento = "";
            char param;
            int kpl = 0;
            //Pilkotaan muunna-komento
            if(syote.length() == 8) {
                komento = syote.substring(0, 6);
                param = syote.charAt(7);
                kpl = Character.getNumericValue(param);
            }
            
            if(syote.equals("inventoi")) {
                //Haetaan tiedot ja palastellaan rivit
                String rivit = Muotoilu.inventoi(taulukko);
                String[] osat = rivit.split("[-]");
                for (String osat1 : osat)
                    System.out.println(osat1);
                jatka = true;
            }
            else if(syote.equals("lataa")) {
                //Alustetaan taulukko sokkelon osille
                Logiikka lo = new Logiikka();
                int siemen = lo.alustaTaulukko();                   
                Automaatti.alusta(siemen);
                taulukko = lo.teeTaulukko();
                jatka = true;
            }
            else if(syote.equals("kartta")) {
                tulosta = true;
                jatka = true;
            }
            else if(syote.equals("tallenna")) {
                //Luetaan sokkelon tiedot tiedostoon
                Tiedosto td = new Tiedosto();
                td.kirjoitaTiedostoon(taulukko);
                jatka = true;
            }
            else if(syote.equals("lopeta")) {
                tulosta = true;
                jatka = false;
            }
            else if(syote.equals("odota")) {
                //Liikutetaan robtteja mutta ei mönkijää
                jatka = true;
                liikRob = true;
                tulosta = true;
            }
            else if(syote.equals("liiku e") || syote.equals("liiku p") || syote.equals("liiku i") || syote.equals("liiku l")) {
                //Liikutaan parametrin osoittamaan suuntaan                  
                char par = syote.charAt(6);
                jatka = ((Monkija)monkija).otaAskel(par, taulukko);
                if(Sisalto.esineet().koko() > 0) {
                    liikRob = true;
                    tulosta = true;
                }
                else
                    tulosta = true;
            }
            else if(syote.equals("katso e") || syote.equals("katso p") || syote.equals("katso i") || syote.equals("katso l")) {
                //Muodostetaan tiedot parametrin osoittaman 
                //suunnan kohdasta sokkelosta
                char para = syote.charAt(6);
                String rivi = Muotoilu.katsoViereinen(para, taulukko);
                String osa[] = rivi.split("[-]");
                for (String osa1 : osa) 
                    System.out.println(osa1);
                jatka = true;
            }
            else if(komento.equals("muunna") && kpl > 0 && kpl <= mKoko) {
                ((Monkija)monkija).muunna(kpl);
                jatka = true;
            }
            else {
                System.out.println("Virhe!");
                jatka = true; 
            }
            
            //Liikutetaan robotteja sokkelossa ja tulostetaan kartta
            if(liikRob) 
                jatka = log.liikutaRobotteja(taulukko);   
            if(tulosta)
                log.tulostaKartta(taulukko);
            
        }        
        while(jatka && Sisalto.esineet().koko() > 0);
        
        //Tulostetaan ennen ohjelman lopettamista
        System.out.println("Ohjelma lopetettu.");
   }
}
