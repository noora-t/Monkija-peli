package muut;
import apulaiset.*;

/**
  * Robottia mallintava luokka.
  * <p>
  * Harjoitustyö, Olio-ohjelmoinnin perusteet, kevät 2016.
  * <p>
  * @author Noora Toimela (Toimela.Noora.E@studnet.uta.fi),
  * Informaatiotieteiden yksikkö, Tampereen yliopisto.
  */

public class Robotti extends Sisalto implements Suunnallinen {
    /**Robotin suunta*/
    public char suunta;
    
    public Robotti() {
        
    }
    public Robotti(int r, int s, int e, char su) {
        rivind = r;
        sarind = s;
        energia = e;
        suunta = su;
    }
    
    // Olion suunnan palauttava metodi.
    @Override
    public char suunta() {
       return 'a';
    }

    /** Olion suunnan asettava metodi.
      *
      * @param ilmansuunta uusi suunta, joka on jokin neljästä pääilmansuunnasta.
      * @throws IllegalArgumentException jos parametri ei ollut jokin yllä
      * määritellyistä pääilmansuunnan symboleista.
      */
    @Override
    public void suunta(char ilmansuunta) throws IllegalArgumentException {
    
    }
    
    //toString-metodin korvaus
    @Override
    public String toString() {
        return super.toString();
    } 
            
    //toteuta rajapinnat
}
