package muut;
import fi.uta.csjola.oope.lista.*;

/**
  * LinkitettyLista-luokasta peritty OmaLista-luokka.
  * <p>
  * Harjoitustyö, Olio-ohjelmoinnin perusteet, kevät 2016.
  * <p>
  * @author Noora Toimela (Toimela.Noora.E@studnet.uta.fi),
  * Informaatiotieteiden yksikkö, Tampereen yliopisto.
  */

public class OmaLista extends LinkitettyLista {
    /** Lisätään listalle uusi alkio
     *
     * @param alkio lisättävä
     */
    @SuppressWarnings("unchecked") // Estetään kääntäjän varoitus.
    public void lisaa(Object alkio) {
        // Luodaan uusi solmu.
        Solmu uusi = new Solmu(alkio); 
        int i = 0;
        boolean jatka = true;
        
        // Tyhjä lista: pää ja häntä ovat sama alkio.
        if (onkoTyhja()) {
           lisaaAlkuun(alkio);
        }
        
        //Listalla on viitteitä
        else {
            while(jatka) {
                // Asetetaan nykyiseen olioon apuviite.
                Object nykyinen = alkio(i);
                // Asetetaan nykyiseen alkioon Comparable-tyyppinen viite
                Comparable vertailtava = (Comparable)nykyinen;

                // Löydettiin parametria suurempi tietoalkio
                if(vertailtava.compareTo(alkio) == 1) {                    
                    lisaaAlkuun(alkio);
                    jatka = false;
                }
                
                // Löydettiin parametria pienempi tai yhtä suuri tietoalkio
                else if(vertailtava.compareTo(alkio) == -1 || vertailtava.compareTo(alkio) == 0) {
                    // Aloitetaan listan päästä
                    Solmu paikassa = paa();  
                    //Kelataan oikeaan kohtaan.
                    for (int j = 0; j < i; j++)
                        paikassa = paikassa.seuraava();
                    
                    //Jos listalla on enemmän solmuja
                    if(paikassa.seuraava() != null) {
                        Solmu seu = paikassa.seuraava();
                        Object apu = alkio(i + 1);                      
                        Comparable vertaa = (Comparable)apu;
                        //Jos seuraava solmu on pienempi tai yhtä suuri kuin
                        //lisättävä solmu, jatketaan silmukointia
                        if(vertaa.compareTo(alkio) == -1 || vertailtava.compareTo(alkio) == 0) {
                            jatka = true;
                        }
                        //Jos seuraava solmu on suuremoi kuin lisättävä,
                        //asetetaan uusi nykyisen ja seuraavan väliin
                        else if(vertaa.compareTo(alkio) == 1) {                           
                            paikassa.seuraava(uusi);
                            uusi.seuraava(seu);
                            jatka = false;
                            // Kasvatetaan listan kokoa yhdellä.
                            koko++;
                        }
                    }
                    //Jos listalla ei ole enempää solmuja,
                    //asetetaan uusi solmu nykyisen jälkeen
                    else {
                        paikassa.seuraava(uusi);
                        jatka = false;
                        // Kasvatetaan listan kokoa yhdellä.
                        koko++;
                    }
                }                  
                i++;
            }                
        }  
    }                  
         
    /** Poistaa annettuun viitteeseen liittyvän alkion listalta.
     * @param alkio
     * @return poistettava
     */
    public Object poista(Object alkio) {
      // Apuviite
      Object poistettava = null;
      
      // Kääntyy todeksi, jos löydetään poistettava alkio.
      boolean loydetty = false;
      
      // Käydään listaa läpi alusta loppuun niin pitkään kuin alkioita on
      // saatavilla tai poistettavaa ei ole löydetty
      int i = 0;
      while (i < koko && !loydetty) {
         // Löydettiin tietoalkio, johon liittyy parametri ja listan solmu
         if (alkio == alkio(i)) {
            // Asetetaan poistettavaan alkioon apuviite
            poistettava = poista(i);
            
            // Löydettiin mitä haettiin.
            loydetty = true;
         }
         
         // Siirrytään seuraavaan paikkaan.
         else
            i++;
      }
      
      // Palalutetaan viite mahdollisesti poistettuun alkioon
      return poistettava;
   }
}