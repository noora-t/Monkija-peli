package muut;

/**
  * Sokkelon seiniä mallintava luokka.
  * <p>
  * Harjoitustyö, Olio-ohjelmoinnin perusteet, kevät 2016.
  * <p>
  * @author Noora Toimela (Toimela.Noora.E@studnet.uta.fi),
  * Informaatiotieteiden yksikkö, Tampereen yliopisto.
  */

public class Seina extends Sokkelo {
    public Seina() {
        
    } 
    public Seina(int r, int s) {
        rivind = r;
        sarind = s;
    }
    
    //toString-metodin korvaus
    @Override
    public String toString() {
        return super.toString();
    } 
}
